Copy code files to sol cluster, can compile using G++ or by coptying 
to vitis and compiling in vitis.